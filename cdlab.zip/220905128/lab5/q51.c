#include<stdio.h>

int main(){
	int num =10;

	printf("%d is %X in hexadecimal\n",num,num);
	return 0;
}

// %X prints hexadecimal