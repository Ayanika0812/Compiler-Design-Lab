#include<stdio.h>
int main()
{
char a;
printf("HI I AM Q2 INPUT\n");

}