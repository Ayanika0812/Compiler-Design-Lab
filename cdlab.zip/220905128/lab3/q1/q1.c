#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int isArithmeticOperator(char c);
int isRelationalOperator(char c, char next);
int isLogicalOperator(char c, char next);
int isSpecialSymbol(char c);
int isKeyword(char *str);
int isIdentifier(char *str);
int isNumeric(char *str);
int isStringLiteral(char *str);

void identifyTokens(char *input, FILE *outputFile) {
    int i = 0;
    int row = 1; 
    int col = 1;
    while (input[i] != '\0') {
        if (input[i] == '\n') {
            row++;
            col = 1;
            i++;
            continue;
        }
        if (isspace(input[i])) {
            i++;  
            col++; 
            continue;
        }
        if (isArithmeticOperator(input[i])) {
            fprintf(outputFile, "<%c,%d,%d>\n", input[i], row, col);
            i++;
            col++;
        }
        else if (input[i] == '=' || input[i] == '<' || input[i] == '>' || input[i] == '!' || input[i] == '&' || input[i] == '|') {
            if (isRelationalOperator(input[i], input[i+1])) {
                fprintf(outputFile, "<%c%c,%d,%d>\n", input[i], input[i+1], row, col);
                i += 2;
                col += 2;
            } else if (isLogicalOperator(input[i], input[i+1])) {
                fprintf(outputFile, "<%c%c,%d,%d>\n", input[i], input[i+1], row, col);
                i += 2;
                col += 2;
            } else {
                fprintf(outputFile, "<%c,%d,%d>\n", input[i], row, col);
                i++;
                col++;
            }
        }
        else if (isSpecialSymbol(input[i])) {
            fprintf(outputFile, "<%c,%d,%d>\n", input[i], row, col);
            i++;
            col++;
        }
        else if (input[i] == '"') {
            int start = i;
            i++;
            while (input[i] != '"' && input[i] != '\0') i++;
            if (input[i] == '"') {
                char str[100];
                strncpy(str, input + start, i - start + 1);
                str[i - start + 1] = '\0';
                fprintf(outputFile, "<%s,%d,%d>\n", str, row, col);
                i++;
                col += (i - start + 1);
            }
        }
        else if (isalpha(input[i]) || input[i] == '_') {
            int start = i;
            while (isalnum(input[i]) || input[i] == '_') i++;
            char str[100];
            strncpy(str, input + start, i - start);
            str[i - start] = '\0';

            if (isKeyword(str)) {
                fprintf(outputFile, "<%s,%d,%d>\n", str, row, col);
            } else if (isIdentifier(str)) {
                fprintf(outputFile, "<id,%d,%d>\n", row, col);
            }
            col += (i - start);
        }
        else if (isdigit(input[i])) {
            int start = i;
            while (isdigit(input[i])) i++;
            char num[100];
            strncpy(num, input + start, i - start);
            num[i - start] = '\0';
            fprintf(outputFile, "<%s,%d,%d>\n", num, row, col);
            col += (i - start);
        } else {
            i++;
            col++;
        }
    }
}
int isArithmeticOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '%');
}
int isRelationalOperator(char c, char next) {
    if (c == '=') {
        return (next == '=');
    } else if (c == '<' || c == '>' || c == '!') {
        return (next == '=' || next == '\0');
    }
    return 0;
}
int isLogicalOperator(char c, char next) {
    if (c == '&' || c == '|') {
        return (next == c);
    }
    return 0;

int isSpecialSymbol(char c) {
    return (c == '{' || c == '}' || c == '[' || c == ']' || c == '(' || c == ')'
            || c == ';' || c == ',' || c == '.' || c == ':' || c == '#');
}
int isKeyword(char *str) {
    const char *keywords[] = {
        "int", "float", "char", "if", "else", "while", "return", "void", "for", "break", "continue", "switch", "case", "default"
    };
    for (int i = 0; i < sizeof(keywords) / sizeof(keywords[0]); i++) {
        if (strcmp(str, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}
int isIdentifier(char *str) {
    if (isalpha(str[0]) || str[0] == '_') {
        for (int i = 1; i < strlen(str); i++) {
            if (!isalnum(str[i]) && str[i] != '_') {
                return 0;
            }
        }
        return 1;
    }
    return 0;
}
int isNumeric(char *str) {
    for (int i = 0; i < strlen(str); i++) {
        if (!isdigit(str[i])) {
            return 0;
        }
    }
    return 1;
}
int isStringLiteral(char *str) {
    return (str[0] == '"' && str[strlen(str) - 1] == '"');
}
int main() {
    char input[] = "int x = 10;\nfloat y = 20.5;\nif (x == y) {\ny = x;\n}";

    FILE *outputFile = fopen("output.txt", "w");
    if (outputFile == NULL) {
        printf("Error opening file!\n");
        return 1;
    }
    identifyTokens(input, outputFile);
    fclose(outputFile);
    printf("Output written to 'output.txt'.\n");
    return 0;
}
}
