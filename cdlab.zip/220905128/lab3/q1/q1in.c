int            main()
{
int a,b             ,sum;
a = 1;
b = 1;
sum = a + b;
}