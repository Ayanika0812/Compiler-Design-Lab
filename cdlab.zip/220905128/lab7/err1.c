main(){
	int a = 5, b ;
	a = a + 5;
	}

