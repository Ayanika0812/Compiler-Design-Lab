#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define TABLE_SIZE 100
typedef struct Node {
    char *verb;
    struct Node *next;
} Node;
Node* hashTable[TABLE_SIZE];
int hash(char *str) {
    int hashValue = 0;
    while (*str) {
        hashValue += *str++;
    }
    return hashValue % TABLE_SIZE;
}

void insert(char *str) {
    int index = hash(str); 
    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->verb = strdup(str); 
    newNode->next = NULL;
    if (hashTable[index] == NULL) {
        hashTable[index] = newNode;
    } else {
        Node *temp = hashTable[index];
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}
int search(char *key) {
    int index = hash(key);
    Node *temp = hashTable[index];
    while (temp != NULL) {
        if (strcmp(temp->verb, key) == 0) {
            return index;
        }
        temp = temp->next;
    }
    return -1;
}
void identifyAndInsertVerbs(char *sentence) {
    char *knownVerbs[] = {"is", "run", "eat", "play", "have", "be", "go", "do", "make"};
    int numVerbs = sizeof(knownVerbs) / sizeof(knownVerbs[0]);
    char *token = strtok(sentence, " ");
    while (token != NULL) {
        for (int i = 0; i < numVerbs; i++) {
            if (strcasecmp(token, knownVerbs[i]) == 0) {
                if (search(token) == -1) {
                    insert(token);
                    printf("Inserted verb: %s\n", token);
                } else {
                    printf("Verb already present: %s\n", token);
                }
            }
        }
        token = strtok(NULL, " "); 
    }
}

int main() {
    char sentence[256];
    for (int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i] = NULL;
    }
    printf("Enter a sentence: ");
    fgets(sentence, sizeof(sentence), stdin);
    sentence[strcspn(sentence, "\n")] = '\0';
    identifyAndInsertVerbs(sentence);
    char searchVerb[50];
    printf("Enter a verb to search: ");
    scanf("%s", searchVerb);
    if (search(searchVerb) != -1) {
        printf("Verb '%s' found in the hash table.\n", searchVerb);
    } else {
        printf("Verb '%s' not found in the hash table.\n", searchVerb);
    }

    return 0;
}

/*
./a.out
Enter a sentence: I will run to the park and play with Carla
Inserted verb: run
Inserted verb: play
Enter a verb to search: play
Verb 'play' found in the hash table.
*/
