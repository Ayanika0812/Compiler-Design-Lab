#include <stdio.h>
#include <stdlib.h>

#define MAX_LINE_LENGTH 1024

// Function to read a line using getc()
int read_line(FILE *file, char *buffer) {
    int i = 0;
    char c;

    // Read characters one by one until newline or EOF
    while ((c = getc(file)) != EOF && c != '\n') {
        buffer[i++] = c;
        if (i >= MAX_LINE_LENGTH - 1) {
            break; // Prevent buffer overflow
        }
    }

    // Null-terminate the string
    buffer[i] = '\0';

    // Return 1 if we read something, else 0
    return (i > 0 || c != EOF);
}

int main() {
    FILE *file1, *file2, *result;
    char line1[MAX_LINE_LENGTH], line2[MAX_LINE_LENGTH];
    char file1_name[100], file2_name[100], result_name[100];

    // Get file names from the user
    printf("Enter the first filename: ");
    scanf("%s", file1_name);
    printf("Enter the second filename: ");
    scanf("%s", file2_name);
    printf("Enter the result filename: ");
    scanf("%s", result_name);

    // Open the first file in read mode
    file1 = fopen(file1_name, "r");
    if (file1 == NULL) {
        perror("Error opening file1");
        return 1;
    }

    // Open the second file in read mode
    file2 = fopen(file2_name, "r");
    if (file2 == NULL) {
        perror("Error opening file2");
        fclose(file1);
        return 1;
    }

    // Open the result file in write mode
    result = fopen(result_name, "w");
    if (result == NULL) {
        perror("Error opening result file");
        fclose(file1);
        fclose(file2);
        return 1;
    }

    // Read and write lines alternately from both files
    while (1) {
        // Read a line from the first file using getc()
        if (read_line(file1, line1)) {
            fputs(line1, result);
            // Write a newline character using putc()
            putc('\n', result);
        }

        // Read a line from the second file using getc()
        if (read_line(file2, line2)) {
            fputs(line2, result);
            // Write a newline character using putc()
            putc('\n', result);
        }

        // Break the loop if both files have reached the end
        if (feof(file1) && feof(file2)) {
            break;
        }
    }

    printf("Lines merged successfully and stored in %s\n", result_name);

    // Close all files
    fclose(file1);
    fclose(file2);
    fclose(result);

    return 0;
}
