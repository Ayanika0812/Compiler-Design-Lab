#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *sourceFile, *destFile;
    char sourceFilename[100], destFilename[100];
    long fileSize;
    int ch;

    printf("Enter the source filename: ");
    scanf("%s", sourceFilename);
    printf("Enter the destination filename: ");
    scanf("%s", destFilename);
    sourceFile = fopen(sourceFilename, "r");
    if (sourceFile == NULL) {
        printf("Error: Could not open source file %s\n", sourceFilename);
        exit(1);
    }
    fseek(sourceFile, 0, SEEK_END);
    fileSize = ftell(sourceFile);
    printf("Size of the source file: %ld bytes\n", fileSize);
    destFile = fopen(destFilename, "w");
    if (destFile == NULL) {
        printf("Error: Could not open destination file %s\n", destFilename);
        fclose(sourceFile);
        exit(1);
    }
    for (long i = fileSize - 1; i >= 0; i--) {
        fseek(sourceFile, i, SEEK_SET);
        ch = fgetc(sourceFile);
        fputc(ch, destFile);
    }
    printf("File contents reversed and stored in %s\n", destFilename);
    printf("\nContents of the destination file (%s):\n", destFilename);
    fclose(destFile);
    destFile = fopen(destFilename, "r");
    
    if (destFile == NULL) {
        printf("Error: Could not open destination file %s for reading.\n", destFilename);
        fclose(sourceFile);
        exit(1);
    }
    while ((ch = fgetc(destFile)) != EOF) {
        putchar(ch);
    }
    fclose(sourceFile);
    fclose(destFile);

    return 0;
}


/*
cc q2.c
student@oslab-02:~/220905128/lab1$ ./a.out
Enter the source filename: srcfile.txt
Enter the destination filename: dstfile.txt
Size of the source file: 24 bytes
File contents reversed and stored in dstfile.txt

Contents of the destination file (dstfile.txt):

321 elif CRS si sihT iH
*/
