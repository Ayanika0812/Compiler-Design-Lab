#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file;
    char filename[100], ch;
    int lineCount = 0, charCount = 0;
    printf("Enter the filename to open: ");
    scanf("%s", filename);
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Could not open file %s\n", filename);
        exit(1);
    }
    while ((ch = fgetc(file)) != EOF) {
        charCount++;
        if (ch == '\n') {
            lineCount++;
        }
    }
    if (charCount > 0 && ch != '\n') {
        lineCount++;
    }
    printf("Total number of lines: %d\n", lineCount);
    printf("Total number of characters: %d\n", charCount);
    fclose(file);

    return 0;
}


/* 
cc q1.c
student@oslab-02:~/220905128/lab1$ ./a.out
Enter the filename to open: file.txt
Total number of lines: 2
Total number of characters: 12
*/

