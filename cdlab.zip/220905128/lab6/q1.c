#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int curr = 0;
char str[100];
void S();
void T();
void Tprime();
void invalid();
void valid();
void invalid() {
    printf("-----------------ERROR!----------------\n");
    exit(0);
}
void valid() {
    printf("----------------SUCCESS!---------------\n");
    exit(0);
}
// S -> a | > | ( T )
void S() {
    if (str[curr] == 'a') {
        curr++;
        return;
    }
    else if (str[curr] == '>') {
        curr++;
        return;
    }
    else if (str[curr] == '(') {
        curr++;  
        T();     
        if (str[curr] == ')') {
            curr++; 
            return;
        } else {
            invalid(); 
        }
    } else {
        invalid();
    }
}
// T -> S T'
void T() {
    S();      
    Tprime(); 
}
// T' -> , S T' | 𝜖
void Tprime() {
    if (str[curr] == ',') {
        curr++;
        S();     
        Tprime();
    }
    // Epsilon
}

int main() {
    printf("Enter String: ");
    scanf("%s", str);
    S();
    if (str[curr] == '\0') {
        valid();
    } else {
        invalid();
    }
    return 0;
}



/*
 cc q1.c 
student@oslab-02:~/220905128/lab6$ ./a.out
Enter String: (a,a)
----------------SUCCESS!---------------

*/