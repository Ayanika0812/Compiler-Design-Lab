#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int curr = 0;
char str[100];
void S();
void L();
void L_prime();
void invalid();
void valid();
void invalid() {
    printf("-----------------ERROR!----------------\n");
    exit(0);
}
void valid() {
    printf("----------------SUCCESS!---------------\n");
    exit(0);
}
// S -> (L) | a
void S() {
    if (str[curr] == '(') {
        curr++;  
        L(); 
        if (str[curr] == ')') {
            curr++; 
            return;
        } else {
            invalid();  
        }
    } else if (str[curr] == 'a') {
        curr++;  
        return;  
    } else {
        invalid(); 
    }
}
// L -> S L'
void L() {
    S(); 
    L_prime(); 
}
// L' -> , S L' |Epsilon
void L_prime() {
    if (str[curr] == ',') {
        curr++; 
        S();    
        L_prime(); 
    }
}
int main() {
    printf("Enter String: ");
    scanf("%s", str);
    S();  
    if (str[curr] == '\0') {
        valid();
    } else {
        invalid();
    }
    return 0;
}


/*
tudent@oslab-02:~/220905128/lab6$ ./a.out
Enter String: (a,a)
----------------SUCCESS!---------------
student@oslab-02:~/220905128/lab6$ ./a.out
Enter String: a
----------------SUCCESS!---------------
student@oslab-02:~/220905128/lab6$ ./a.out
Enter String: ((,a
-----------------ERROR!----------------
student@oslab-02:~/220905128/lab6$ ./a.out
Enter String: ((,a)
*/