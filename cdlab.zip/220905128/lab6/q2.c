#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int curr = 0;
char str[100];
void S();
void U();
void V();
void W();
void invalid();
void valid();
void invalid() {
    printf("-----------------ERROR!----------------\n");
    exit(0);
}
void valid() {
    printf("----------------SUCCESS!---------------\n");
    exit(0);
}
// S -> UVW
void S() {
    U();
    V();
    W();
}
// U -> (S) | aSb | d
void U() {
    if (str[curr] == '(') {
        curr++;
        S();  
        if (str[curr] == ')') {
            curr++;
            return;
        } else {
            invalid();
        }
    } else if (str[curr] == 'a') {
        curr++;
        S();  
        if (str[curr] == 'b') {
            curr++;
            return;
        } else {
            invalid();
        }
    } else if (str[curr] == 'd') {
        curr++;
        return;
    } else {
        invalid();
    }
}
// V -> aV |Epsilon
void V() {
    if (str[curr] == 'a') {
        curr++;
        V(); 
    }
    //Epsilon
}

// W -> cW | Epsilon
void W() {
    if (str[curr] == 'c') {
        curr++;
        W(); 
    }
    //Epsilon
}
int main() {
    printf("Enter String: ");
    scanf("%s", str);
    S(); 
    if (str[curr] == '\0') {
        valid();
    } else {
        invalid();
    }
    return 0;
}


/* cc q2.c 
student@oslab-02:~/220905128/lab6$ ./a.out
Enter String: (adb)
----------------SUCCESS!---------------
*/