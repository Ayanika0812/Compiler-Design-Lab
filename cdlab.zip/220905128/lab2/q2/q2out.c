


void printValue(int value) { printf("%d", value); }

int main()
{
    printValue(gfg); // gfg = 50
    PrintLineNum;
    printf("#hi");
    return 0;

}