main() {
    int x, y[10];
    char z;
    
    x = 5;
    
    if (x > 10) {
        y[0] = 20;
    } else {
        z = 'a';
    }
}

