main() {
    int x[10];
    x[a] = 20; 
}

