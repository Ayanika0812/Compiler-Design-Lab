void main(){
int a,b,c;
int d;
char s;
a = b + c;
}